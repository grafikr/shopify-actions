This is a theme "placeholder". Shopify requires a zip when creating a new file.
